import http.server
import socketserver
import webbrowser
import os

PORT = 8000

# Создаем обработчик запросов
Handler = http.server.SimpleHTTPRequestHandler

# Запускаем сервер
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Сервер запущен на http://localhost:{PORT}")
    print("Открываю браузер...")

    # Автоматически открываем браузер
    webbrowser.open(f'http://localhost:{PORT}')

    print("Для остановки сервера нажмите Ctrl+C")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nСервер остановлен")
        httpd.shutdown()